$(document).on('click','#close_modal', function(){
	$('.preloader').hide();
})

